/* =========================================================
   MOBILE ONLY - CA-R34
   - crea una scena separata da ruotare su telefono
   - attiva la rotazione dopo il primo click sulla donnina
   - aggiunge supporto touch agli elementi già gestiti via mouse
   ========================================================= */

(function () {
  const MOBILE_QUERY = "(max-width: 900px)";

  function isMobileWidth() {
    return window.matchMedia(MOBILE_QUERY).matches;
  }

  function createMobileStage() {
    if (document.querySelector(".mobile-rotate-stage")) return;

    const stage = document.createElement("div");
    stage.className = "mobile-rotate-stage";

    const nodesToMove = Array.from(document.body.childNodes).filter((node) => {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node;
        if (el.tagName === "SCRIPT") return false;
        if (el.classList.contains("mobile-rotate-stage")) return false;
      }
      return true;
    });

    document.body.insertBefore(stage, document.body.firstChild);
    nodesToMove.forEach((node) => stage.appendChild(node));
  }

  function activateLandscapeAfterFirstClick() {
    const donnina = document.getElementById("donnina");
    if (!donnina) return;

    donnina.addEventListener("click", () => {
      if (!isMobileWidth()) return;
      document.body.classList.add("mobile-landscape-active");
    });
  }

  function makeMouseEvent(type, touch, coordsOverride) {
    const clientX = coordsOverride && typeof coordsOverride.clientX === "number" ? coordsOverride.clientX : touch.clientX;
    const clientY = coordsOverride && typeof coordsOverride.clientY === "number" ? coordsOverride.clientY : touch.clientY;

    return new MouseEvent(type, {
      bubbles: true,
      cancelable: true,
      view: window,
      button: 0,
      buttons: type === "mouseup" ? 0 : 1,
      clientX,
      clientY,
      screenX: touch.screenX || clientX,
      screenY: touch.screenY || clientY
    });
  }

  function getMobileDragCoords(touch, target) {
    if (!document.body.classList.contains("mobile-landscape-active")) {
      return { clientX: touch.clientX, clientY: touch.clientY };
    }

    const slider = target.closest(".slider");

    /* La scena mobile è ruotata di 90°. Per gli slider orizzontali il movimento
       naturale del dito corrisponde meglio all'asse Y dello schermo. Lo amplifichiamo
       leggermente per rendere il trascinamento meno faticoso. */
    if (slider && slider.classList.contains("horizontal")) {
      return {
        clientX: touch.clientY * 1.55,
        clientY: touch.clientY
      };
    }

    return { clientX: touch.clientX, clientY: touch.clientY };
  }

  function enableTouchToMouseBridge() {
    let activeTarget = null;

    document.addEventListener("touchstart", (e) => {
      if (!isMobileWidth()) return;

      /* IMPORTANTE:
         Non intercettiamo #donnina: deve ricevere il suo click nativo,
         altrimenti il primo tap viene bloccato e non parte il reveal. */
      const target = e.target.closest(".cursore, .cerchio, .cerchio-btn, .btn-top, .btn-bottom, #nav-btn");
      if (!target || !e.touches.length) return;

      activeTarget = target;
      const touch = e.touches[0];
      target.dispatchEvent(makeMouseEvent("mousedown", touch, getMobileDragCoords(touch, target)));
      e.preventDefault();
    }, { passive: false });

    document.addEventListener("touchmove", (e) => {
      if (!isMobileWidth() || !activeTarget || !e.touches.length) return;

      const touch = e.touches[0];
      window.dispatchEvent(makeMouseEvent("mousemove", touch, getMobileDragCoords(touch, activeTarget)));
      e.preventDefault();
    }, { passive: false });

    document.addEventListener("touchend", (e) => {
      if (!isMobileWidth() || !activeTarget) return;

      const touch = e.changedTouches[0] || { clientX: 0, clientY: 0, screenX: 0, screenY: 0 };
      window.dispatchEvent(makeMouseEvent("mouseup", touch, getMobileDragCoords(touch, activeTarget)));

      /* Per bottoni semplici convertiamo anche il tap in click.
         Slider e cerchi usano invece mousedown/mousemove/mouseup. */
      if (activeTarget.matches(".cerchio-btn, .btn-top, .btn-bottom, #nav-btn")) {
        activeTarget.click();
      }

      activeTarget = null;
      e.preventDefault();
    }, { passive: false });
  }

  function enableIdleDemo() {
    let timer = null;
    let demoRunning = false;

    function clearDemoClasses() {
      document.querySelectorAll(".mobile-idle-demo-circle, .mobile-idle-demo-cursor").forEach((el) => {
        el.classList.remove("mobile-idle-demo-circle", "mobile-idle-demo-cursor");
      });
      demoRunning = false;
    }

    function runDemo() {
      if (!isMobileWidth()) return;
      if (!document.body.classList.contains("mobile-landscape-active")) return;
      if (demoRunning) return;

      const circle = document.getElementById("cerchio-1");
      const cursor = document.querySelector("#slider-5 .cursore");
      const demoEl = circle || cursor;
      if (!demoEl) return;

      demoRunning = true;
      demoEl.classList.add(circle ? "mobile-idle-demo-circle" : "mobile-idle-demo-cursor");
      setTimeout(clearDemoClasses, 1300);
      scheduleDemo();
    }

    function scheduleDemo() {
      clearTimeout(timer);
      if (!isMobileWidth()) return;
      if (!document.body.classList.contains("mobile-landscape-active")) return;
      timer = setTimeout(runDemo, 4000);
    }

    ["touchstart", "mousedown", "click", "keydown"].forEach((evt) => {
      document.addEventListener(evt, () => {
        clearDemoClasses();
        scheduleDemo();
      }, { passive: true });
    });

    const donnina = document.getElementById("donnina");
    if (donnina) {
      donnina.addEventListener("click", () => {
        setTimeout(scheduleDemo, 50);
      });
    }
  }

  createMobileStage();
  activateLandscapeAfterFirstClick();
  enableTouchToMouseBridge();
  enableIdleDemo();
})();
